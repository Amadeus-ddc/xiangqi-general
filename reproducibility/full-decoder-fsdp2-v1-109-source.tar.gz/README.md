# Actual full-decoder training source

This archive contains the exact 109 Python modules used by the full-model four-GPU capacity/resume probe and the initial explanation SFT. Its source identity differs from the evolving repository head. SOURCE_MANIFEST.json records every module hash and the completed 1790-test consumer verification.

Install the repository dependencies in a virtual environment first. Extract this archive into a fresh directory. To select the preserved implementation, set PYTHONPATH to the extracted source directory and XQGENERAL_CODE_REVISION to full-decoder-fsdp2-v1-109-frozen, then invoke the existing training CLI with Python -P and a real, verified configuration.

Weights, expert assets, data, logs, test inputs and optimizer checkpoints are not included. Training still requires their original contracts. Changing paths or distributed geometry creates a different experiment and does not establish exact optimizer continuation. The archive preserves code identity; it does not prove model quality or completion of training. LICENSE and THIRD_PARTY_NOTICES.md accompany the source.
