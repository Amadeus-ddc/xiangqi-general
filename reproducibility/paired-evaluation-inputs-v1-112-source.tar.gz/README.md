# Actual paired development-evaluation source

This preserves the exact 112-module `paired-evaluation-inputs-112-v1` execution
source used for the complete normal/zero/shuffled development evaluation and
full auxiliary BF16 prose review. Each module matches its completed 1922-test
consumer proof. This is distinct from the actual 109-module initial-SFT
producer, which has a separate published archive.

Current public source contains subsequent fixes in training.py, inference.py
and model_bundle.py. This archive preserves the evaluated implementation,
including its historical inference cache behavior; it is not a claim that the
new public runtime was used for those results.

The archive contains project Python source and notices only. Models, datasets,
feature caches, environment, query inputs and runtime logs are not included.
It is not an end-to-end reproduction package or a useful-coach certification.
Use the original artifact manifests for assets and actual run identity.
